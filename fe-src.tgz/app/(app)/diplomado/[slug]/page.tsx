"use client";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { api, DiplomaDetailT } from "@/lib/api";

export default function DiplomaPage() {
  const params = useParams<{ slug: string }>();
  const slug = params?.slug as string;
  const [d, setD] = useState<DiplomaDetailT | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!slug) return;
    api.get<DiplomaDetailT>(`/api/diplomas/${slug}`).then(setD).catch((e) => setError(e.message));
  }, [slug]);

  if (error) return <div className="card" style={{ padding: 24, color: "var(--danger)" }}>{error}</div>;
  if (!d) return <span className="muted">Cargando…</span>;

  const t = d.teacher;

  return (
    <div className="grid" style={{ gap: 22 }}>
      <div>
        <Link href="/explorar" className="muted" style={{ fontSize: 13 }}>← Diplomados</Link>
        <h1 style={{ fontSize: 28, fontWeight: 800, marginTop: 8, color: "#fff" }}>{d.title}</h1>
        {d.description && <p className="muted" style={{ marginTop: 6 }}>{d.description}</p>}
        <div style={{ marginTop: 14 }}>
          <div style={{ height: 10, borderRadius: 999, background: "rgba(5,8,15,.6)", border: "1px solid var(--line)", overflow: "hidden" }}>
            <div style={{ width: `${d.progress}%`, height: "100%", background: "var(--grad)" }} />
          </div>
          <div className="muted" style={{ fontSize: 12.5, marginTop: 6 }}>{d.completed_lessons}/{d.total_lessons} lecciones · {d.progress}% completado</div>
        </div>
      </div>

      {/* Profesor del diplomado */}
      {t && (
        <div className="card" style={{ padding: 16, display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{ width: 56, height: 56, borderRadius: 999, flexShrink: 0,
            background: t.photo_url ? `center/cover url(${t.photo_url})` : "linear-gradient(135deg,var(--cyan),var(--indigo))" }} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="muted" style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: ".08em" }}>Tu profesor</div>
            <div style={{ fontWeight: 800, color: "#fff" }}>{t.name}</div>
            {t.bio && <p className="muted" style={{ fontSize: 13, marginTop: 3 }}>{t.bio}</p>}
          </div>
          {t.whatsapp && (
            <a className="btn btn-wa" style={{ padding: "9px 14px", fontSize: 13, flexShrink: 0 }}
              href={`https://wa.me/${t.whatsapp.replace(/[^0-9]/g, "")}`} target="_blank" rel="noreferrer">
              <svg width="16" height="16" viewBox="0 0 448 512" fill="currentColor" aria-hidden><path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zM223.9 438.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.5-186.6 184.5zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.3-5-3.7-10.5-6.5z"/></svg>
              WhatsApp
            </a>
          )}
        </div>
      )}

      {d.modules.map((m, mi) => (
        <div key={m.id} className="card" style={{ padding: 18 }}>
          {/* Cabecera del módulo: imagen cuadrada a la izquierda del título */}
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            {m.cover_url && <div style={{ width: 88, height: 88, borderRadius: 12, flexShrink: 0, background: `center/cover url(${m.cover_url})` }} />}
            <div style={{ minWidth: 0 }}>
              <div className="muted" style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: ".08em" }}>Módulo {mi + 1}</div>
              <div style={{ fontWeight: 800, fontSize: 19, color: "#fff", lineHeight: 1.2 }}>{m.title}</div>
              {m.description && <div className="muted" style={{ fontSize: 13, marginTop: 3 }}>{m.description}</div>}
            </div>
          </div>

          <div style={{ marginTop: 14, display: "grid", gap: 8 }}>
            {m.lessons.map((l, li) => (
              <Link key={l.id} href={`/leccion/${l.id}`}
                style={{ display: "flex", alignItems: "center", gap: 12, padding: "11px 14px", borderRadius: 12,
                  border: "1px solid var(--line)", background: "rgba(5,8,15,.5)" }}>
                <span style={{ width: 26, height: 26, borderRadius: 999, display: "grid", placeItems: "center", fontSize: 12.5, fontWeight: 700, flexShrink: 0,
                  background: l.completed ? "var(--f4)" : "var(--grad-soft)", color: l.completed ? "#04110b" : "var(--cyan)" }}>
                  {li + 1}
                </span>
                <span style={{ flex: 1, fontSize: 14 }}>{l.title}</span>
                {l.completed && <span style={{ color: "var(--f4)", fontSize: 12 }}>✓</span>}
                <span className="muted" style={{ fontSize: 12 }}>▶</span>
              </Link>
            ))}
            {m.lessons.length === 0 && <span className="muted" style={{ fontSize: 13 }}>Sin lecciones todavía.</span>}
          </div>
        </div>
      ))}
    </div>
  );
}
